#ifndef _CONSOLE
#define _CONSOLE

void clear();
void putchar(char c);
void print(char* str, ...);
void print_int(int n);
char getchar();

#endif
